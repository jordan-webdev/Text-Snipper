=== Text Snipper ===
Contributors: Jordan Carter
Tags: text, snip, text snipper, ellipses, truncate, multi-line, overflow, trim, ...
Tested up to: 4.7
Stable tag: 1.0
Author URI: https://jordanwebdev.com
License: GPLv3 or later

A simple text snipper that trims down multi-line overflowing text and adds an ellipses("...") to it. Expect updates to come soon with more functionality.

== Description ==

This plugin allows you to specify in the settings page a CSS class, and then looks for any elements that contain it and trims the text down so that it does not overflow its height. This is for vertical trimming of multi-line text. The plugin is rather simple at the moment, but expect updates in the not to far future.

= HOW TO USE =

Once you install and activate the plugin, there will be a new tab for it under the "settings" admin menu. Go to this page, and enter the name of the CSS class you are using in your HTML to specifiy which elements should be truncated. Click save, and that's it!

== Installation ==

1. Download from plugins repository
2. Activate plugin

== Frequently Asked Questions ==

There is no FAQ at this time.

== Changelog ==

1.0 - 22/Nov/2016

* FIX: Fix a PHP error in the notices code (regression in 1.12.28)

1.12.28 - 11/Dec/2016

* Launch!

== Screenshots ==

1. Settings page with an HTML class entered.
2. Truncation in action.

== License ==

    Copyright 20116 Jordan Carter

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA