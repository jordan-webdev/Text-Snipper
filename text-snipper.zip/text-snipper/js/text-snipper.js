(function($) {
    //Praveen Prasad "HasScrollBar" function adapted http://stackoverflow.com/questions/7341865/checking-if-jquery-is-loaded-using-javascript
    $.fn.hasOverflow = function() {
        var elm = $(this);
        var hasOverflow = false; 
        if ( elm.clientHeight < elm.scrollHeight ) {
            hasOverflow = true;
        }
        return hasOverflow;
    }
    //http://www.mail-archive.com/discuss@jquery.com/msg04261.html
    jQuery.fn.reverse = [].reverse;

    $(document).ready( function() {
        
        if (  $('.' + snipClass).length > 0 ) {
            
            var count = 0;
            
            for (var i = 0; i < 10000; i++) {
                $('.' + snipClass).each( function () {
                    
                    var el = this;
                    
                    //Check for overflows
                    if ( el.clientHeight < el.scrollHeight) {
                        if ($(this).children().length > 0) { //Handle child elements
                            $("> *", this).reverse().each( function () {
                                for (var j = 0; j < 10000; j++) {  
                                    if ( $(this).text() != "" && el.clientHeight < el.scrollHeight ) {
                                        $(this).text($(this).text().substring(0,$(this).text().length - 1));
                                    } else {
                                        break;
                                    }
                                }  
                            });   
                        } else { //Handle elements with no children
                            $(this).text($(this).text().substring(0,$(this).text().length - 1));
                        }
                    } else { //Add '...'
                        count++;
                    }
                    
                });
                
                //Add ... once finished
                if ( count >= $('.' + snipClass).length) {
                    $('.' + snipClass).each( function () {
                        var el = this;
                        if ($(this).children().length > 0) { //Handle child elements
                                $("> *", this).reverse().each( function () {
                                   if ( $(this).text() != "" ) {
                                       $(this).text($(this).text().substring(0, $(this).text().length - 3) + "...");
                                   }
                                });
                            } else { //Handle elements with no children
                                $(this).text($(this).text().substring(0, $(this).text().length - 3) + "...");
                            }
                    });
                        break;
                }
                
            }  
        }
    });

}(jQuery));